﻿/*
 * CSE212 
 * (c) BYU-Idaho
 * 09-Prove
 * 
 * It is a violation of BYU-Idaho Honor Code to post or share this code with others or 
 * to post it online.  Storage into a personal and private repository (e.g. private
 * GitHub repository, unshared Google Drive folder) is acceptable.
 */

using prove_01;

Console.WriteLine("\n======================\nProve 1 - Arrays / Lists\n======================");
ArraysTester.Run();
